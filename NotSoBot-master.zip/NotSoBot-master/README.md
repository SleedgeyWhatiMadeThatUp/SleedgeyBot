# NotSoBot
### Requires:
- Python 3.5
- [discord.py](https://github.com/rapptz/discord.py)
- lots of Python modules

[![NotSoSuper's Dev](https://discordapp.com/api/guilds/178313653177548800/widget.png?style=banner2)](https://discord.gg/QQENx4f)

**Bot Invite**: `https://discordapp.com/oauth2/authorize?client_id=170903265565736960&scope=bot&permissions=8`

I won't mind if you take some code to learn or improve but please don't be a skid.

Feel free to ask me questions, NotSoSuper#8800 on Discord.

The MySQL database scheme is included in `discord.sql`, you will have to reverse or replace the enviormental variables in the code for proper results.

Shoutout to DBot for help with multiple imagemagick commands along with some MySQL tips and the amazing developers over on Discord API - discord.py channel.
